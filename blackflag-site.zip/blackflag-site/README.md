# blackflag-site

Marketing site for **Black Flag Exterior Cleaning &amp; Soft Washing**. Static
HTML/CSS/JS. No build step, no framework, no backend.

Modelled on the conventions in `pattengalec/lancerfarms-v2` — design tokens in one
stylesheet, one config file that owns every changeable value, shared chrome injected
by a single script, and long comments explaining *why* a decision was made rather
than restating what the code does.

---

## Files

| File | What it owns |
|---|---|
| `bfc-config.js` | **Every** phone number, email, city, service and price. Start here. |
| `bfc-photos.js` | **Every** image URL. One edit swaps the whole site to real photos. |
| `bfc-theme.css` | Design tokens and shared components (nav, cards, buttons, forms). |
| `bfc-nav.js` | Header, mobile drawer, footer, sticky call bar. Injected on every page. |
| `index.html` | Home |
| `services.html` | Five services, each with an anchor (`#pressure`, `#soft`, `#solar`, `#gutter`, `#lighting`) |
| `gallery.html` | Work grid |
| `about.html` | About + service area |
| `contact.html` | Estimate request form |
| `bf-emblem.svg` | Logo (vector, type already outlined) |
| `bf-emblem-white.svg` | One-colour knockout version |
| `favicon-192.png` | Favicon |

**No `CNAME` file.** That is a GitHub Pages mechanism. This site is intended for
Cloudflare Pages, where the custom domain is set in the dashboard instead. If you
end up on GitHub Pages, add a `CNAME` file containing just the bare domain.

---

## Before this goes anywhere real

Three things are placeholders and all three are in `bfc-config.js`:

1. **Phone** — `(757) 555-0123`. Also update `PHONE_HREF` (digits only, E.164).
2. **Email and domain** — `quotes@blackflagclean.com`, `blackflagclean.com`.
3. **Service area** — the 757 area code and the Hampton Roads city list came from
   the original mock design. Almost certainly wrong. Replace `REGION` and `CITIES`.

Then the photos. Every image is a free-licence Unsplash photo hot-linked from
Unsplash's CDN — legal, but not what a real business should ship. Two slots in
`bfc-photos.js` are marked `SWAP FIRST` because the picture does not show the
service it is labelled with (there is no good free gutter or holiday-lighting
photo). Replace those first.

To use real photos: make an `/img` folder, drop the files in, and change the `src`
values in `bfc-photos.js` from `u('photo-…')` to `'img/whatever.jpg'`. Nothing else
changes — no page hard-codes an image path.

---

## The contact form does not capture leads

`contact.html` validates the input then opens the visitor's own mail app with
everything pre-filled. It works with zero hosting cost, but if the visitor abandons
the draft the business never knows they were there.

To make it real, pick one:

- **Formspree / Basin / Netlify Forms** — wrap the fields in a `<form action=…>`
  and delete the `mailto` handler. Fastest option, roughly ten minutes.
- **Supabase** — a `bfc_leads` table with an RLS policy allowing anonymous
  `INSERT` but no `SELECT`, exactly like the `lfg_access_requests` pattern in
  lancerfarms-v2. Only do this if the business wants a dashboard.

Whichever way, never put a service-role key in a static page.

---

## Publishing from a phone (no terminal)

1. **github.com → New repository.** Name it `blackflag-site`. Public or private
   both work with Cloudflare Pages. Do not add a README — this file is one.
2. **Add file → Upload files.** Upload every file in this folder to the repo root.
   Files must sit at the root, not inside a subfolder, or the paths break.
3. **Commit to `main`.**
4. **Cloudflare dashboard → Workers &amp; Pages → Create → Pages → Connect to Git.**
   Pick the repo. Framework preset **None**. Build command **empty**. Output
   directory **`/`**. Deploy.
5. Cloudflare gives you a `*.pages.dev` URL immediately. Open it and check the
   phone link, the drawer, and that photos load.
6. Custom domain later: **Pages project → Custom domains → Set up a domain.**

After that, any commit to `main` — including edits typed in GitHub's mobile web
editor — republishes automatically. A change is only live once the commit is on
`main` **and** the Cloudflare deployment shows Success. Confirm at the real URL,
with a hard refresh.

---

## Editing on a phone

Open the file on github.com, tap the pencil, edit, commit. Because everything
changeable lives in `bfc-config.js` and `bfc-photos.js`, most real edits are one
file and a few lines — which is the whole point of the structure.
