/* ═══════════════════════════════════════════════════════════════
   bfc-photos.js — every photograph on this site, in one list
   ───────────────────────────────────────────────────────────────
   THE ONE PLACE IMAGES LIVE. No <img src> anywhere else in the
   site points at a real URL — pages carry a data-photo="key" and
   this file resolves it. Swapping the whole site over to the
   business's own job photos is therefore a single-file edit, not a
   hunt through five HTML documents.

   ⚠ THESE ARE STOCK PHOTOGRAPHS. Every image below is a free-licence
   Unsplash photo, hosted on Unsplash's CDN and hot-linked. That is
   fine for a demo and legal under the Unsplash Licence (free for
   commercial use, no attribution required), but it is NOT what a
   real business should ship:

     1. Hot-linking means the images vanish if Unsplash changes a
        URL. Nothing here is under our control.
     2. Stock photos of other people's houses sell nobody. Real
        before-and-after shots of actual jobs outperform stock by a
        wide margin in this trade, because the whole purchase
        decision is "will my house look like that."

   TO REPLACE: put real photos in an /img folder in this repo and
   change the `src` values below to 'img/whatever.jpg'. Keep the
   keys and the `alt` text — the alt text is what screen readers and
   Google read, and it is written per-image on purpose.

   A few slots are marked SWAP FIRST. Those are stock images standing
   in for work the photo does not actually show (there is no good
   free gutter or holiday-lighting photograph). They are the most
   misleading and should be the first ones replaced.
   ═══════════════════════════════════════════════════════════════ */

/* Unsplash serves resized images from query parameters, so one source
   photo covers every breakpoint. Width is set per use below. */
function u(id, w) {
  return 'https://images.unsplash.com/' + id +
         '?auto=format&fit=crop&q=70&w=' + (w || 1600);
}

window.BFC_PHOTOS = {

  /* ── hero ──────────────────────────────────────────────────── */
  hero: {
    src: u('photo-1718152521364-b9655b8a7926', 2000),
    alt: 'A worker in a high-visibility vest pressure washing a paved surface'
  },

  /* ── service cards. Keys match BFC.SERVICES[].id ───────────── */
  pressure: {
    src: u('photo-1718152470408-cfeebeb6b9fc', 1200),
    alt: 'Pressure washer cleaning a hard surface, dirt lifting away from the jet'
  },
  soft: {
    src: u('photo-1630608354129-6a7704150401', 1200),
    alt: 'Clean white and black timber house exterior under an open sky'
  },
  solar: {
    src: u('photo-1655300256335-beef51a914fe', 1200),
    alt: 'Residential roof covered with solar panels'
  },
  gutter: {
    /* SWAP FIRST — a clean house, not a gutter being cleared. */
    src: u('photo-1583345237708-add35a664d77', 1200),
    alt: 'Roofline and gutter run on a clean residential exterior'
  },
  lighting: {
    /* SWAP FIRST — a house at dusk, no lights installed. */
    src: u('photo-1623005399550-57b86a3539a8', 1200),
    alt: 'Brick home exterior at dusk'
  },

  /* ── gallery. Captions are deliberately specific: vague ones
        ("great result!") read as filler and get skipped. ─────── */
  gallery: [
    { src:u('photo-1718152421680-d1580e843cc9',900),
      alt:'Pressure washing a paved walkway',
      cap:'Walkway · concrete', note:'Two seasons of algae, one pass.' },
    { src:u('photo-1718152423993-a29048dbc223',900),
      alt:'Worker cleaning a street surface with a pressure washer',
      cap:'Driveway · commercial', note:'Oil shadow pre-treated before the rinse.' },
    { src:u('photo-1730807908064-c087959dd52c',900),
      alt:'House roof with a full array of solar panels',
      cap:'Solar array · residential', note:'Deionised water, soft brush, no pressure.' },
    { src:u('photo-1637417494521-78b4d1d33029',900),
      alt:'Home with solar panels on a pitched roof',
      cap:'Roof + panels', note:'Soft wash on the shingle, DI water on the glass.' },
    { src:u('flagged/photo-1566838616631-f2618f74a6a2',900),
      alt:'Brick house with solar panels on the roof',
      cap:'Brick · soft wash', note:'Low pressure. Mortar stays where it belongs.' },
    { src:u('photo-1718152521364-b9655b8a7926',900),
      alt:'Operator pressure washing paving in a high-visibility vest',
      cap:'Patio · pavers', note:'Sand re-swept after the surface dried.' }
  ],

  /* ── about page ────────────────────────────────────────────── */
  truck: {
    src: u('photo-1640802396402-094375631000', 1400),
    alt: 'Pickup truck parked in front of a residential home'
  }
};

/* Resolve every data-photo on the page. Called by bfc-nav.js on load,
   so no page has to remember to do it.

   Images are decoded off the main thread and faded in on load, which
   keeps the hero from flashing a half-drawn JPEG on a slow phone. */
window.BFC_MOUNT_PHOTOS = function () {
  document.querySelectorAll('[data-photo]').forEach(function (el) {
    var p = window.BFC_PHOTOS[el.dataset.photo];
    if (!p) { return; }
    el.src = p.src;
    el.alt = p.alt;
    el.loading = el.dataset.eager ? 'eager' : 'lazy';
    el.decoding = 'async';
    if (el.complete) { el.classList.add('ready'); }
    else { el.addEventListener('load', function () { el.classList.add('ready'); }); }
  });
};
