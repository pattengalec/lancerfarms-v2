/* ═══════════════════════════════════════════════════════════════
   bfc-nav.js — renders the header, drawer, footer and call bar
   ───────────────────────────────────────────────────────────────
   One file draws the chrome on every page, so a new link is added
   in one place instead of five. Pages declare nothing; this script
   reads window.BFC (bfc-config.js) for the business details and
   works out the current page from the URL.

   LOAD ORDER, and it matters:
       bfc-config.js  →  bfc-photos.js  →  bfc-nav.js
   This script reads BFC at run time and calls BFC_MOUNT_PHOTOS at
   the end, so both must already exist.

   ── DESIGN RULES, deliberate. Please keep them. ──────────────────
   1. THE PHONE NUMBER IS NEVER MORE THAN ONE TAP AWAY. Header CTA
      on desktop, pinned call bar on mobile. Everything else on this
      site is decoration around that one action.
   2. TAP TARGETS ARE 52px, not the 44px minimum. Visitors are
      outdoors, one-handed, often in sunlight. The failure mode is
      hitting the neighbouring control, so spacing matters as much
      as size.
   3. THE DRAWER TRAPS FOCUS AND CLOSES ON ESCAPE. A drawer that
      leaves focus behind it strands keyboard and screen-reader
      users on a page they cannot see.
   4. NO EDGE-SWIPE TO OPEN. Swipe conflicts with the browser's own
      back gesture on iOS. The burger is the only opener.
   ═══════════════════════════════════════════════════════════════ */
(function () {
  'use strict';

  var C = window.BFC;
  if (!C) { console.error('bfc-nav: bfc-config.js must load first'); return; }

  var LINKS = [
    { label: 'Home',     href: 'index.html' },
    { label: 'Services', href: 'services.html' },
    { label: 'Gallery',  href: 'gallery.html' },
    { label: 'About',    href: 'about.html' },
    { label: 'Contact',  href: 'contact.html' }
  ];

  /* Current page. Treat a bare directory as index.html so the site
     works both at /index.html and at / on a static host. */
  var here = location.pathname.split('/').pop() || 'index.html';

  function esc(s) {
    return String(s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }

  var tel = 'tel:' + C.PHONE_HREF;

  /* ── header ─────────────────────────────────────────────────── */
  var navLinks = LINKS.map(function (l) {
    var cur = l.href === here ? ' aria-current="page"' : '';
    return '<a href="' + l.href + '"' + cur + '>' + esc(l.label) + '</a>';
  }).join('');

  var header =
    '<header class="hdr"><div class="wrap hdr__in">' +
      '<a class="hdr__logo" href="index.html" aria-label="' + esc(C.FULL) + ' — home">' +
        '<img src="bf-emblem.svg" alt="" width="100" height="62">' +
        '<span class="hdr__name">' + esc(C.NAME) +
          '<small>EXTERIOR CLEANING &amp; SOFT WASHING</small></span>' +
      '</a>' +
      '<nav class="hdr__nav" aria-label="Main">' + navLinks + '</nav>' +
      '<a class="btn btn--primary hdr__cta" href="' + tel + '">' + esc(C.PHONE) + '</a>' +
      '<button class="burger" id="bfcBurger" aria-label="Open menu" ' +
        'aria-expanded="false" aria-controls="bfcDrawer"><span></span></button>' +
    '</div></header>';

  /* ── drawer ─────────────────────────────────────────────────── */
  var drawer =
    '<div class="scrim" id="bfcScrim"></div>' +
    '<aside class="drawer" id="bfcDrawer" role="dialog" aria-modal="true" aria-label="Menu">' +
      '<button class="drawer__close" id="bfcClose" aria-label="Close menu">&times;</button>' +
      '<nav aria-label="Mobile">' +
        LINKS.map(function (l) {
          return '<a class="drawer__link" href="' + l.href + '">' + esc(l.label) + '</a>';
        }).join('') +
      '</nav>' +
      '<a class="btn btn--primary btn--block" style="margin-top:22px" href="' + tel + '">' +
        'Call ' + esc(C.PHONE) + '</a>' +
      '<p style="margin-top:18px;font-size:13px;color:var(--paper-soft)">' +
        esc(C.REGION) + '</p>' +
    '</aside>';

  /* ── footer ─────────────────────────────────────────────────── */
  var svcLinks = C.SERVICES.map(function (s) {
    return '<li><a href="services.html#' + s.id + '">' + esc(s.name) + '</a></li>';
  }).join('');

  var hours = C.HOURS.map(function (h) {
    return '<li>' + esc(h[0]) + '<br><span style="color:var(--paper-mute)">' + esc(h[1]) + '</span></li>';
  }).join('');

  var footer =
    '<footer class="ftr"><div class="wrap">' +
      '<div class="ftr__grid">' +
        '<div>' +
          '<img src="bf-emblem.svg" alt="" width="132" height="82" style="margin-bottom:14px">' +
          '<p style="font-size:14px;color:var(--paper-soft);max-width:30ch">' + esc(C.TAGLINE) + '</p>' +
        '</div>' +
        '<div><h4>Services</h4><ul>' + svcLinks + '</ul></div>' +
        '<div><h4>Service area</h4><ul><li>' +
          C.CITIES.map(esc).join('</li><li>') + '</li></ul></div>' +
        '<div><h4>Hours</h4><ul>' + hours + '</ul>' +
          '<p style="margin-top:16px"><a href="' + tel + '" style="color:var(--paper);font-weight:700">' +
          esc(C.PHONE) + '</a><br><a href="mailto:' + esc(C.EMAIL) + '">' + esc(C.EMAIL) + '</a></p>' +
        '</div>' +
      '</div>' +
      '<div class="ftr__legal">' +
        '<span>&copy; ' + new Date().getFullYear() + ' ' + esc(C.FULL) + '. Est. ' + C.EST + '.</span>' +
        '<span>Demonstration site &mdash; contact details are placeholders.</span>' +
      '</div>' +
    '</div></footer>';

  /* ── mobile call bar ────────────────────────────────────────── */
  var callbar =
    '<div class="callbar">' +
      '<a class="btn btn--primary" href="' + tel + '">Call now</a>' +
      '<a class="btn btn--ghost" href="contact.html">Free estimate</a>' +
    '</div>';

  /* ── mount ──────────────────────────────────────────────────── */
  document.body.insertAdjacentHTML('afterbegin', header + drawer);
  document.body.insertAdjacentHTML('beforeend', footer + callbar);

  var burger = document.getElementById('bfcBurger'),
      scrim  = document.getElementById('bfcScrim'),
      panel  = document.getElementById('bfcDrawer'),
      close  = document.getElementById('bfcClose'),
      last   = null;

  function open() {
    last = document.activeElement;
    scrim.classList.add('show');
    panel.classList.add('show');
    burger.setAttribute('aria-expanded', 'true');
    document.body.style.overflow = 'hidden';
    close.focus();
  }
  function shut() {
    scrim.classList.remove('show');
    panel.classList.remove('show');
    burger.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
    if (last) { last.focus(); }
  }

  burger.addEventListener('click', open);
  close.addEventListener('click', shut);
  scrim.addEventListener('click', shut);
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && panel.classList.contains('show')) { shut(); }
  });

  /* Focus trap: Tab cycles inside the drawer while it is open. */
  panel.addEventListener('keydown', function (e) {
    if (e.key !== 'Tab') { return; }
    var f = panel.querySelectorAll('a[href], button');
    if (!f.length) { return; }
    var first = f[0], lastEl = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); lastEl.focus(); }
    else if (!e.shiftKey && document.activeElement === lastEl) { e.preventDefault(); first.focus(); }
  });

  /* Fill in any element tagged with a config key, so pages never
     hard-code a phone number: <span data-bfc="PHONE"></span> */
  document.querySelectorAll('[data-bfc]').forEach(function (el) {
    var v = C[el.dataset.bfc];
    if (typeof v === 'string') { el.textContent = v; }
  });
  document.querySelectorAll('[data-bfc-tel]').forEach(function (el) {
    el.href = tel;
  });

  if (window.BFC_MOUNT_PHOTOS) { window.BFC_MOUNT_PHOTOS(); }
})();
