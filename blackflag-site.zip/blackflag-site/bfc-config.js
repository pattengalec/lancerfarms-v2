/* ═══════════════════════════════════════════════════════════════
   bfc-config.js — Black Flag Exterior Cleaning: business details
   ───────────────────────────────────────────────────────────────
   Every page reads its contact and service information from here.
   Nothing else in the site should contain a phone number, an email
   address, a city name, or a price.

   WHY ONE FILE. A service business changes its phone number, adds a
   city, or drops a service far more often than it redesigns a page.
   When those values are typed into six HTML files, five of them go
   stale and nobody notices until a customer calls a dead number.
   Change it here once and every page follows.

   ⚠ PLACEHOLDERS — REPLACE BEFORE THIS GOES ANYWHERE REAL.
   The phone, email, domain and service area below are invented. The
   757 area code and Hampton Roads cities came from the original mock
   design and are almost certainly wrong for the real business.
   ═══════════════════════════════════════════════════════════════ */
window.BFC = {

  /* ── identity ─────────────────────────────────────────────── */
  NAME:      'Black Flag',
  FULL:      'Black Flag Exterior Cleaning & Soft Washing',
  TAGLINE:   'Raising the standard. Protecting your home.',

  /* ── contact ⚠ placeholders ───────────────────────────────── */
  PHONE:      '(757) 555-0123',
  PHONE_HREF: '+17575550123',          /* tel: link — digits only, E.164 */
  EMAIL:      'quotes@blackflagclean.com',
  DOMAIN:     'blackflagclean.com',

  /* ── where they work ⚠ placeholders ───────────────────────── */
  REGION: 'Hampton Roads, Virginia',
  CITIES: ['Virginia Beach', 'Chesapeake', 'Norfolk', 'Suffolk',
           'Portsmouth', 'Hampton'],

  HOURS: [
    ['Monday – Friday', '7:00 am – 6:00 pm'],
    ['Saturday',        '8:00 am – 4:00 pm'],
    ['Sunday',          'Closed — estimates by request']
  ],

  /* ── the work ─────────────────────────────────────────────────
     `id` matches the anchor on services.html and the key in
     bfc-photos.js. Keep the three in sync or a card loses its
     picture and its link at the same time.                      */
  SERVICES: [
    { id:'pressure', name:'Pressure Washing',
      blurb:'Driveways, walkways, patios and concrete brought back to the colour they started as.',
      detail:'High-pressure water strips out embedded dirt, oil shadow, tyre marks and algae from hard surfaces that can take the force — concrete, pavers, brick and stone. Surfaces are pre-treated so the dirt releases instead of being blasted loose, which means fewer passes and no wand stripes left behind.' },

    { id:'soft', name:'Soft Washing',
      blurb:'Low-pressure cleaning for siding, roofs and anything pressure would damage.',
      detail:'Roofs, vinyl siding, stucco, painted wood and screens get a low-pressure application of cleaning solution that kills the algae and mildew at the root, then a gentle rinse. Pressure on these surfaces forces water behind the cladding and voids most roofing warranties. Soft washing also lasts longer, because the growth is killed rather than knocked off.' },

    { id:'solar', name:'Solar Panel Cleaning',
      blurb:'Deionised water and soft brushes. No pressure, no warranty risk.',
      detail:'Dust, pollen and bird droppings on panels cut output measurably, and the loss compounds across a whole array. Panels are cleaned with deionised water and soft brushes — never pressure, never detergent — so nothing is left behind to streak and no seal, coating or manufacturer warranty is put at risk.' },

    { id:'gutter', name:'Gutter Cleaning',
      blurb:'Cleared, flushed and checked for flow — inside and out.',
      detail:'Gutters are hand-cleared, downspouts flushed until they run clean, and the run checked for sagging, separated seams and pitch problems. The outside face is washed too, because tiger-striping on the fascia is what people actually see from the kerb.' },

    { id:'lighting', name:'Holiday Lighting',
      blurb:'Design, install, maintain, take down and store. Seasonal.',
      detail:'Commercial-grade lighting installed on rooflines, columns and landscaping, then maintained through the season, removed in January and stored until next year. Nobody balances on their own roof in December.' }
  ],

  /* ── proof points shown in the trust bar ──────────────────── */
  TRUST: ['Fully insured', 'Residential & commercial',
          'Free written estimates', 'Satisfaction guaranteed'],

  /* Year founded — shown in the badge and the footer. */
  EST: 2024
};
